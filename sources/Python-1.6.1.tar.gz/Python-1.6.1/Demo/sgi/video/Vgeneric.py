import sys, posixpath
exec('import ' + posixpath.basename(sys.argv[0]) + '\n')
